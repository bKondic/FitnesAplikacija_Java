package fitnessAplikacija;
import org.mindrot.jbcrypt.*;
import fitnessAplikacija.Login;
import fitnessAplikacija.Idle;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Registracija {

	private JFrame frame;
	private JTextField ime;
	private JTextField prezime;
	private JTextField email;
	private JTextField brojMobitela;
	private JTextField tjelesnaTezina;
	private JPasswordField lozinka;
	private JPasswordField ponovljenaLozinka;
	private JTextField dob;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registracija window = new Registracija();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static boolean provjeraZnakova(String rijec) {
		
		for(int i = 0; i < rijec.length(); i++) {
			
			char znak = rijec.charAt(i);
			
			if(Character.isDigit(znak)) {
				return true;
			}
		}
		return false;	
	}
	
	public static boolean provjeraMaila(String mail) {
		
		if(mail.contains("@") && ((mail.contains(".com") || mail.contains(".hr")) || mail.contains(".net") || mail.contains(".org"))) {
			return true;
		}
		return false;
	}
	
	public static boolean provjeraBrojeva(String broj) {
		
		for(char c : broj.toCharArray()) {
			if(Character.isLetter(c)) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean provjeraPraznogPolja(String unos) {
		
		if(unos.length() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Create the application.
	 */
	public Registracija() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		
		
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				
			}
		});
		frame.setBounds(100, 100, 460, 380);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("IME");
		lblNewLabel.setBounds(25, 35, 137, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PREZIME");
		lblNewLabel_1.setBounds(25, 60, 137, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("E-MAIL");
		lblNewLabel_2.setBounds(25, 85, 137, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("BROJ MOBITELA");
		lblNewLabel_3.setBounds(25, 110, 137, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("ODABIR SPOLA");
		lblNewLabel_4.setBounds(25, 135, 137, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("TJELESNA TEŽINA");
		lblNewLabel_5.setBounds(25, 160, 137, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("LOZINKA");
		lblNewLabel_6.setBounds(25, 215, 138, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("PONOVLJENA LOZINKA");
		lblNewLabel_7.setBounds(25, 240, 165, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		ime = new JTextField();
		ime.setBounds(200, 32, 175, 20);
		frame.getContentPane().add(ime);
		ime.setColumns(10);
		
		prezime = new JTextField();
		prezime.setBounds(200, 57, 175, 20);
		frame.getContentPane().add(prezime);
		prezime.setColumns(10);
		
		email = new JTextField();
		email.setBounds(200, 82, 175, 20);
		frame.getContentPane().add(email);
		email.setColumns(10);
		
		brojMobitela = new JTextField();
		brojMobitela.setBounds(200, 107, 175, 20);
		frame.getContentPane().add(brojMobitela);
		brojMobitela.setColumns(10);
		
		JComboBox spol = new JComboBox();
		spol.setModel(new DefaultComboBoxModel(new String[] {"M", "Z"}));
		spol.setBounds(200, 131, 51, 22);
		frame.getContentPane().add(spol);
		
		tjelesnaTezina = new JTextField();
		tjelesnaTezina.setBounds(200, 157, 175, 20);
		frame.getContentPane().add(tjelesnaTezina);
		tjelesnaTezina.setColumns(10);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(200, 212, 175, 20);
		frame.getContentPane().add(lozinka);
		
		ponovljenaLozinka = new JPasswordField();
		ponovljenaLozinka.setBounds(200, 234, 175, 20);
		frame.getContentPane().add(ponovljenaLozinka);
		
		JLabel lblNewLabel_8 = new JLabel("DOB");
		lblNewLabel_8.setBounds(25, 190, 105, 14);
		frame.getContentPane().add(lblNewLabel_8);
		
		dob = new JTextField();
		dob.setBounds(200, 188, 51, 20);
		frame.getContentPane().add(dob);
		dob.setColumns(10);
		
		JButton btnNewButton = new JButton("REGISTRACIJA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String imes, prezimes, brojMobitelas, emails, spols, tjelesnaTezinas, lozinkas, ponovljenaLozinkas, dobs;				
				imes = ime.getText();
				prezimes = prezime.getText();
				brojMobitelas = brojMobitela.getText();
				emails = email.getText();
				spols = (String) spol.getSelectedItem();
				tjelesnaTezinas = tjelesnaTezina.getText();
				dobs = dob.getText();
				lozinkas = new String(lozinka.getPassword());
				ponovljenaLozinkas = new String(ponovljenaLozinka.getPassword());
				
				String salt = BCrypt.gensalt();
				String hashLozinke=BCrypt.hashpw(lozinkas, salt);
				
				
				
				
				if(provjeraPraznogPolja(imes) || provjeraPraznogPolja(prezimes) || provjeraPraznogPolja(brojMobitelas) || provjeraPraznogPolja(emails)
						|| provjeraPraznogPolja(tjelesnaTezinas) || provjeraPraznogPolja(lozinkas) || provjeraPraznogPolja(ponovljenaLozinkas) || provjeraPraznogPolja(dobs)) {
					
					JOptionPane.showMessageDialog(null, "Niste unijeli vrijednost u jedno od polja.");
					
				}else {
					
					if(provjeraZnakova(imes)) {
						
						JOptionPane.showMessageDialog(null, "Ime ne smije sadržavati numeričke vrijednosti.");
					
					}else {
						
						if(provjeraZnakova(prezimes)) {
							JOptionPane.showMessageDialog(null, "Prezime ne smije sadržavati nurmeričke vrijednosti.");
						
						}else {
							
							if(!provjeraMaila(emails)) {
								JOptionPane.showMessageDialog(null, "Niste unijeli valjanu mail adresu. Adresa mora sadržavati znak '@' i jedno od nastavka:.com, .net, .org, .hr.");
							
							}else {
								
								if(provjeraBrojeva(brojMobitelas)) {
									JOptionPane.showMessageDialog(null, "Broj mobitela smije sadržavati samo numeričke vrijednosti.");
								
								}else {
									
									if(provjeraBrojeva(tjelesnaTezinas)) {
										
										JOptionPane.showMessageDialog(null, "Tjelesna težina smije sadržavati samo numeričke vrijednosti.");
									
									}else {
										
										if (provjeraBrojeva(dobs)) {
											
											JOptionPane.showMessageDialog(null, "Dob smije sadržavati samo numeričke vrijednosti");
											
										}else {
											
											if(lozinkas.equals(ponovljenaLozinkas)) {
												
												try {
													
													Class.forName("com.mysql.cj.jdbc.Driver");				
													Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
													
													String select = "SELECT * FROM Vjezbac WHERE Broj_mobitela=?";
													
													PreparedStatement psSelect = con.prepareStatement(select);					
													psSelect.setString(1,brojMobitelas);					
													ResultSet rs = psSelect.executeQuery();
													
													if(rs.next()) {
														JOptionPane.showMessageDialog(null, "Registracija neuspješna. Korisnik sa tim brojem mobitela već postoji.");
													}else {
														
														String insert = "INSERT INTO Vjezbac(Ime, Prezime, Dob, Broj_mobitela, E_mail, Spol, Tjelesna_tezina, Lozinka) VALUES (?,?,?,?,?,?,?,?)";
														
														PreparedStatement psInsert = con.prepareStatement(insert);
														
														psInsert.setString(1, imes);
														psInsert.setString(2, prezimes);
														psInsert.setString(3, dobs);
														psInsert.setString(4, brojMobitelas);
														psInsert.setString(5, emails);
														psInsert.setString(6, spols);
														psInsert.setString(7, tjelesnaTezinas);
														psInsert.setString(8, hashLozinke);
														
														int ubacenoRedaka = psInsert.executeUpdate();
														if(ubacenoRedaka == 1) {
															JOptionPane.showMessageDialog(null, "Registracija je uspješna.");
															
										
															String noviID = "SELECT LAST_INSERT_ID()";
															Statement stnoviID = con.createStatement();
															ResultSet rsnoviID = stnoviID.executeQuery(noviID);
																				
															int noviIDVjezbaca = 0;
															if(rsnoviID.next()) {
																
																noviIDVjezbaca = rsnoviID.getInt(1);
																
															}
															
															String unosUProgres = "INSERT INTO Progres_vjezbaca (id_vjezbaca, id_treninga) SELECT ?, id_treninga FROM Trening";
															PreparedStatement psunosaUProgres = con.prepareStatement(unosUProgres);								
															psunosaUProgres.setInt(1, noviIDVjezbaca);		
															int dodaniVjezbac = psunosaUProgres.executeUpdate();
	
															String trening1 = "UPDATE Progres_vjezbaca SET Redni_BrojTreninga = 1 WHERE id_treninga IN(1,2,3,4,5,6)";																
															Statement stPrviTrening = con.createStatement();
															int prviTrening = stPrviTrening.executeUpdate(trening1);
															
															String trening2 = "UPDATE Progres_vjezbaca SET Redni_BrojTreninga = 2 WHERE id_treninga IN(7,8,9,10,11)";																		
															Statement stDrugiTrening = con.createStatement();
															int drugiTrening = stDrugiTrening.executeUpdate(trening2);
															
															String trening3 = "UPDATE Progres_vjezbaca SET Redni_BrojTreninga = 3 WHERE id_treninga IN(12,13,14,15)";							
															Statement stTreciTrening = con.createStatement();
															int treciTrening = stTreciTrening.executeUpdate(trening3); 
															
															String trening4 = "UPDATE Progres_vjezbaca SET Redni_BrojTreninga = 4 WHERE id_treninga IN(16,17,18,19,20,21,22)";
															Statement stCetvrtiTrening = con.createStatement();
															int cetvrtiTrening = stCetvrtiTrening.executeUpdate(trening4);
															
															Login povratak = new Login();
															povratak.showWindow();
															closeWindow();
																													
														}else {
															JOptionPane.showMessageDialog(null, "Registracija neuspješna.");
														}																					
													}
													
												}catch(Exception e1) {
													JOptionPane.showMessageDialog(null, e1);
												}
												
											}else {
												JOptionPane.showMessageDialog(null, "Lozinke se ne podudaraju.");
											}										
										}
									}
								}
							}
						}
					}						
				}										
			}
		});
		btnNewButton.setBounds(128, 279, 123, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Idle povratakIdle = new Idle();
				povratakIdle.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(10, 309, 58, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		
		
	}

	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
}
