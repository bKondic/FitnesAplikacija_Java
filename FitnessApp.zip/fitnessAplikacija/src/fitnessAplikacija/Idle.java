package fitnessAplikacija;
import java.awt.EventQueue;
import fitnessAplikacija.PocetniZaslon;
import fitnessAplikacija.Login;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Idle {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Idle window = new Idle();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Idle() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 382, 162);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("PRIJAVA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login prijava = new Login();
				prijava.showWindow();
				closeWindow();
			}
		});
		btnNewButton.setBounds(22, 44, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("REGISTRACIJA");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registracija registracija = new Registracija();
				registracija.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(184, 44, 146, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("<-");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PocetniZaslon povratak = new PocetniZaslon();
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_2.setBounds(10, 91, 45, 23);
		frame.getContentPane().add(btnNewButton_2);
	}

	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
}
