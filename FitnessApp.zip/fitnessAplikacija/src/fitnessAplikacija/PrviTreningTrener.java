package fitnessAplikacija;
import fitnessAplikacija.KlijentiIliTreningzi;
import java.sql.*;
import java.awt.EventQueue;
import fitnessAplikacija.KlijentiIliTreningzi;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;

public class PrviTreningTrener {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrviTreningTrener window = new PrviTreningTrener();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrviTreningTrener() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1377, 515);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(217, 102, 1112, 278);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"NAZIV VJE\u017DBE", "RASPON PONAVLJANJA", "ODMOR IZME\u0110U SERIJA", "BROJ SERIJA"
			}
			
		));
		
		JLabel lblNewLabel = new JLabel("REDNI BROJ TRENINGA");
		lblNewLabel.setBounds(25, 36, 183, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JComboBox combo = new JComboBox();
		combo.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4"}));
		combo.setBounds(253, 32, 77, 22);
		frame.getContentPane().add(combo);
		
		JButton btnNewButton = new JButton("ISPIŠI");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String combos;
				combos = (String) combo.getSelectedItem();
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.setRowCount(0);
					
					switch(combos) {
					
					case "1":
						
						String ispis = "SELECT naziv_vjezbe, raspon_ponavljanja_unutar_jedne_radne_serije, odmor_izmedju_radnih_serija, Broj_radnih_serija FROM Trening WHERE id_treninga IN(1,2,3,4,5,6)";
						PreparedStatement psIspisa1 = con.prepareStatement(ispis);
						ResultSet rsIspisa1 = psIspisa1.executeQuery();
						
						while(rsIspisa1.next()) {
							
							String naziv = rsIspisa1.getString(1);
							String raspon = rsIspisa1.getString(2);
							String odmor = rsIspisa1.getString(3);
							int brojSerija = rsIspisa1.getInt(4);
							
							model.addRow(new Object[] {naziv, raspon, odmor, brojSerija});
							
						}
						break;
						
					case "2":
						
						String ispis2 = "SELECT naziv_vjezbe, raspon_ponavljanja_unutar_jedne_radne_serije, odmor_izmedju_radnih_serija, Broj_radnih_serija FROM Trening WHERE id_treninga IN(7, 8, 9 ,10, 11)";
						PreparedStatement psIspisa2 = con.prepareStatement(ispis2);
						ResultSet rsIspisa2 = psIspisa2.executeQuery();
						
						while(rsIspisa2.next()) {
							
							String naziv = rsIspisa2.getString(1);
							String raspon = rsIspisa2.getString(2);
							String odmor = rsIspisa2.getString(3);
							int brojSerija = rsIspisa2.getInt(4);
							
							model.addRow(new Object[] {naziv, raspon, odmor, brojSerija});
							
						}
						break;
						
					case "3":
						
						String ispis3 = "SELECT naziv_vjezbe, raspon_ponavljanja_unutar_jedne_radne_serije, odmor_izmedju_radnih_serija, Broj_radnih_serija FROM Trening WHERE id_treninga IN(12,13,14,15)";
						PreparedStatement psIspisa3 = con.prepareStatement(ispis3);
						ResultSet rsIspisa3 = psIspisa3.executeQuery();
						
						while(rsIspisa3.next()) {
							
							String naziv = rsIspisa3.getString(1);
							String raspon = rsIspisa3.getString(2);
							String odmor = rsIspisa3.getString(3);
							int brojSerija = rsIspisa3.getInt(4);
							
							model.addRow(new Object[] {naziv, raspon, odmor, brojSerija});
							
						}
						break;
						
					case "4":
						
						String ispis4 = "SELECT naziv_vjezbe, raspon_ponavljanja_unutar_jedne_radne_serije, odmor_izmedju_radnih_serija, Broj_radnih_serija FROM Trening WHERE id_treninga IN(16, 17, 18, 19, 20, 21, 22)";
						PreparedStatement psIspisa4 = con.prepareStatement(ispis4);
						ResultSet rsIspisa4 = psIspisa4.executeQuery();
						
						while(rsIspisa4.next()) {
							
							String naziv = rsIspisa4.getString(1);
							String raspon = rsIspisa4.getString(2);
							String odmor = rsIspisa4.getString(3);
							int brojSerija = rsIspisa4.getInt(4);
							
							model.addRow(new Object[] {naziv, raspon, odmor, brojSerija});
							
						}
						break;
					
					}
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
				
			}
		});
		btnNewButton.setBounds(25, 110, 168, 53);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("AŽURIRAJ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int idTreninga=0, serije;
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					int odabraniRedak = table.getSelectedRow();
					if(odabraniRedak>=0) {
						
						String naziv = table.getValueAt(odabraniRedak, 0).toString();
						String raspon = table.getValueAt(odabraniRedak, 1).toString();
						String odmor = table.getValueAt(odabraniRedak, 2).toString();
						String brojSerija = table.getValueAt(odabraniRedak, 3).toString();
						serije = Integer.parseInt(brojSerija);
						
						String dohvatiId = "SELECT id_treninga FROM Trening WHERE naziv_vjezbe='"+naziv+"'";
						PreparedStatement psId=con.prepareStatement(dohvatiId);
						ResultSet rsId = psId.executeQuery();
						
						if(rsId.next()) {
							idTreninga = rsId.getInt(1);
						}
						
						String azuriraj = "UPDATE Trening SET raspon_ponavljanja_unutar_jedne_radne_serije=?, odmor_izmedju_radnih_serija=?, Broj_radnih_serija=? WHERE id_treninga='"+idTreninga+"'";
						PreparedStatement psAzuriranja = con.prepareStatement(azuriraj);

						psAzuriranja.setString(1, raspon);
						psAzuriranja.setString(2, odmor);
						psAzuriranja.setInt(3, serije);
						
						int azuriranoRedaka = psAzuriranja.executeUpdate();
						if(azuriranoRedaka==1) {
							JOptionPane.showMessageDialog(null, "Uspješno ažurirano.");
						}else {
							JOptionPane.showMessageDialog(null, "Došlo je do pogreške.");
						}
						
						
					}else {
						JOptionPane.showMessageDialog(null, "Krivi odabir kod redaka.");
					}
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Greška.");
				}
				
			}
		});
		btnNewButton_1.setBounds(25, 198, 168, 53);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("<-");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				KlijentiIliTreningzi mogucnosti = new KlijentiIliTreningzi();
				mogucnosti.showWindow();
				closeWindow();
			}
		});
		btnNewButton_2.setBounds(25, 430, 54, 23);
		frame.getContentPane().add(btnNewButton_2);
		table.getColumnModel().getColumn(0).setPreferredWidth(192);
		table.getColumnModel().getColumn(1).setPreferredWidth(139);
		table.getColumnModel().getColumn(2).setPreferredWidth(147);
		table.getColumnModel().getColumn(3).setPreferredWidth(101);
	}
	public void showWindow() {
		frame.setVisible(true);
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
	
	public static boolean parsiranjeIntegera(String podatak) {
		
		try {
			
			int provjera = Integer.parseInt(podatak);
			return true;
			
		}catch(Exception e1) {
			return false;
		}
		
	}
}
