package fitnessAplikacija;
import fitnessAplikacija.PrikazProgresaClanova;
import fitnessAplikacija.PrviTreningTrener;
import fitnessAplikacija.LoginTrenera;
import fitnessAplikacija.PopisClanova;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class KlijentiIliTreningzi {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KlijentiIliTreningzi window = new KlijentiIliTreningzi();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public KlijentiIliTreningzi() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 400, 242);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("KLIJENTI");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PopisClanova clanovi = new PopisClanova();
				clanovi.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton.setBounds(93, 49, 184, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("TRENINZI");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PrviTreningTrener treninzi = new PrviTreningTrener();
				treninzi.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(93, 100, 184, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("PROGRES KLIJENATA");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PrikazProgresaClanova progres = new PrikazProgresaClanova();
				progres.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_2.setBounds(93, 148, 184, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1_1 = new JButton("<-");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LoginTrenera povratak = new LoginTrenera();
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1_1.setBounds(10, 171, 58, 23);
		frame.getContentPane().add(btnNewButton_1_1);
	}
	
	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}

}
