package fitnessAplikacija;
import fitnessAplikacija.KlijentiIliTreningzi;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PopisClanova {

	private JFrame frame;
	private JTable table;
	private JScrollPane scrollPane;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PopisClanova window = new PopisClanova();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PopisClanova() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					String ispisClanova = "SELECT * FROM Vjezbac";
					
					Statement stmtClanova = con.createStatement();
					ResultSet rsClanova = stmtClanova.executeQuery(ispisClanova);
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					
					model.setRowCount(0);
					
					while(rsClanova.next()) {
						
						String ime = rsClanova.getString(2);
						String prezime = rsClanova.getString(3);
						int dob = rsClanova.getInt(4);
						String brojMobitela = rsClanova.getString(5);
						String eMail = rsClanova.getString(6);
						String spol = rsClanova.getString(7);
						float tjelesnaTezina = rsClanova.getFloat(8);
						
						model.addRow(new Object[] {ime, prezime, dob, brojMobitela, eMail, spol, tjelesnaTezina});
						
					}
					
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		frame.setBounds(100, 100, 739, 430);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("IZBRIŠI ČLANA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					
					int odabranRedak = table.getSelectedRow();
					int idVjezbaca=0;
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					if(odabranRedak>=0) {
						
						String brojMobitela = table.getValueAt(odabranRedak, 3).toString();
						
						String vjezbac = "SELECT id_vjezbaca FROM Vjezbac WHERE Broj_mobitela='"+brojMobitela+"'";
						PreparedStatement psVjezbaca = con.prepareStatement(vjezbac);
						ResultSet rsVjezbaca = psVjezbaca.executeQuery();
					
						if(rsVjezbaca.next()) {
							idVjezbaca=rsVjezbaca.getInt(1);
						}
						
						String obrisiIzProgresa = "DELETE FROM Progres_vjezbaca WHERE id_vjezbaca='"+idVjezbaca+"'";
						PreparedStatement psProgresa=con.prepareStatement(obrisiIzProgresa);
						
						int obrisiProgres = psProgresa.executeUpdate();
						
							
						String obrisiClana = "DELETE FROM Vjezbac WHERE id_vjezbaca='"+idVjezbaca+"'";
						PreparedStatement psObrisiClana = con.prepareStatement(obrisiClana);
							
						int obrisaniClan = psObrisiClana.executeUpdate();
						if(obrisaniClan==1) {
							JOptionPane.showMessageDialog(null, "Član je uspješno obrisan.");
						}
							
						else {
							JOptionPane.showMessageDialog(null, "Došlo je do pogreške prilikom brisanja progresa.");
						}						
						
						model.removeRow(odabranRedak);
						
					}
					
					
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, e1);
				}
				
				
				
			}
		});
		btnNewButton.setBounds(579, 363, 124, 23);
		frame.getContentPane().add(btnNewButton);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 705, 343);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"IME", "PREZIME", "DOB", "BROJ MOBITELA", "E-MAIL", "SPOL", "TJELESNA TE\u017DINA"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				KlijentiIliTreningzi povratak = new KlijentiIliTreningzi();
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(10, 363, 58, 23);
		frame.getContentPane().add(btnNewButton_1);
		table.getColumnModel().getColumn(0).setPreferredWidth(118);
		table.getColumnModel().getColumn(1).setPreferredWidth(110);
		table.getColumnModel().getColumn(2).setPreferredWidth(46);
		table.getColumnModel().getColumn(3).setPreferredWidth(128);
		table.getColumnModel().getColumn(4).setPreferredWidth(193);
		table.getColumnModel().getColumn(5).setPreferredWidth(46);
		table.getColumnModel().getColumn(6).setPreferredWidth(116);
	}
	
	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
	
}
