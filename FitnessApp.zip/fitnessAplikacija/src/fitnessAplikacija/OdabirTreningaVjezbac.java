package fitnessAplikacija;
import fitnessAplikacija.PrviTreningVjezbac;
import fitnessAplikacija.TreciTreningVjezbac;
import java.sql.*;
import java.awt.EventQueue;
import fitnessAplikacija.CetvrtiTreningVjezbac;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import fitnessAplikacija.DrugiTreningVjezbac;
public class OdabirTreningaVjezbac {

	private JFrame frame;
	JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OdabirTreningaVjezbac window = new OdabirTreningaVjezbac();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OdabirTreningaVjezbac() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 521, 469);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(10, 11, 87, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("PRVI TRENING");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				
				PrviTreningVjezbac prvi = new PrviTreningVjezbac();
				prvi.lblNewLabel.setText(mobitel);
				prvi.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton.setBounds(139, 45, 203, 42);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnDrugiTrening = new JButton("DRUGI TRENING");
		btnDrugiTrening.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				
				DrugiTreningVjezbac drugi = new DrugiTreningVjezbac();
				drugi.lblNewLabel.setText(mobitel);
				drugi.showWindow();
				closeWindow();
			}
		});
		btnDrugiTrening.setBounds(139, 123, 203, 42);
		frame.getContentPane().add(btnDrugiTrening);
		
		JButton btnTreiTrening = new JButton("TREĆI TRENING");
		btnTreiTrening.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				TreciTreningVjezbac treci = new TreciTreningVjezbac();
				treci.lblNewLabel.setText(mobitel);
				treci.showWindow();
				closeWindow();
			}
		});
		btnTreiTrening.setBounds(139, 206, 203, 42);
		frame.getContentPane().add(btnTreiTrening);
		
		JButton btnetvrtiTrening = new JButton("ČETVRTI TRENING");
		btnetvrtiTrening.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				
				CetvrtiTreningVjezbac cetvrti = new CetvrtiTreningVjezbac();
				cetvrti.lblNewLabel.setText(mobitel);
				cetvrti.showWindo();
				closeWindow();
				
			}
		});
		btnetvrtiTrening.setBounds(139, 287, 203, 42);
		frame.getContentPane().add(btnetvrtiTrening);
		
		
		
		
	}
	public void showWindow() {
		frame.setVisible(true);
	}
	
	public void closeWindow() {
		frame.setVisible(false);
	}
}
