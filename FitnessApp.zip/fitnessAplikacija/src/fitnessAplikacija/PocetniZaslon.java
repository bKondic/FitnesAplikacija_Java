package fitnessAplikacija;
import fitnessAplikacija.LoginTrenera;
import fitnessAplikacija.Idle;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PocetniZaslon {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PocetniZaslon window = new PocetniZaslon();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PocetniZaslon() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 395, 264);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("TRENER");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				LoginTrenera loginTrenera = new LoginTrenera();
				loginTrenera.showWindow();
				closeWindow();
				
			}

		});
		btnNewButton.setBounds(123, 50, 123, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("VJEŽBAČ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Idle odabirOpcijaVjezbaca = new Idle();
				odabirOpcijaVjezbaca.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(123, 103, 123, 23);
		frame.getContentPane().add(btnNewButton_1);
	}

	public void showWindow() {

		frame.setVisible(true);
		
	}
	public void closeWindow() {
		frame.setVisible(false);
	}
}
