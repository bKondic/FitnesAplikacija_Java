package fitnessAplikacija;
import java.sql.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import fitnessAplikacija.OdabirTreningaVjezbac;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
public class TreciTreningVjezbac {

	private JFrame frame;
	private JTable table;
	JLabel lblNewLabel;
	private JButton btnAurirajPodatke;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_1;
	private JTextField ttezina;
	private JButton btnAurirajteTjelesnuTeinu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TreciTreningVjezbac window = new TreciTreningVjezbac();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TreciTreningVjezbac() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1146, 512);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(955, 11, 113, 14);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("UNESITE TJELESNU TEŽINU");
		lblNewLabel_1.setBounds(36, 28, 174, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		ttezina = new JTextField();
		ttezina.setBounds(256, 25, 96, 20);
		frame.getContentPane().add(ttezina);
		ttezina.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 92, 1059, 296);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"NAZIV VJE\u017DBE", "RASPON PONAVLJANJA", "ODMOR IZME\u0110U SERIJA", "BROJ RADNIH SERIJA", "PODIGNUTO OPTERE\u0106ENJE", "BROJ PONAVLJANJA"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JButton btnNewButton = new JButton("ISPIŠI VJEŽBE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String mobitel = lblNewLabel.getText();
				int idVjezbaca=0;
				
				try{
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					String vjezbac = "SELECT id_vjezbaca FROM Vjezbac WHERE Broj_mobitela ='"+mobitel+"'";
					PreparedStatement psVjezbaca = con.prepareStatement(vjezbac);
					ResultSet rsVjezbaca = psVjezbaca.executeQuery();
					
					if(rsVjezbaca.next()) {
						idVjezbaca=rsVjezbaca.getInt(1);
					}
					
					String ispis = "SELECT Trening.naziv_vjezbe, Trening.raspon_ponavljanja_unutar_jedne_radne_serije,Trening.odmor_izmedju_radnih_serija, Trening.Broj_radnih_serija,Progres_vjezbaca.podignuto_opterecenje, Progres_vjezbaca.broj_ponavljanja_unutar_radne_serije FROM Trening LEFT OUTER JOIN Progres_vjezbaca ON Trening.id_treninga=Progres_vjezbaca.id_treninga WHERE Progres_vjezbaca.id_vjezbaca='"+idVjezbaca+"' AND Trening.id_treninga IN(12,13,14,15)";
					PreparedStatement psIspisa = con.prepareStatement(ispis);
					ResultSet rsIspisa = psIspisa.executeQuery();
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.setRowCount(0);
					
					while(rsIspisa.next()) {
						
						String naziv = rsIspisa.getString(1);
						String raspon = rsIspisa.getString(2);
						String odmor = rsIspisa.getString(3);
						int serije = rsIspisa.getInt(4);
						double opterecenje = rsIspisa.getDouble(5);
						int brojSerija = rsIspisa.getInt(6);
						
						
						model.addRow(new Object[] {naziv, raspon, odmor, serije, opterecenje, brojSerija});
						
					}
					
					
					
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
				
			}
		});
		btnNewButton.setBounds(79, 406, 268, 58);
		frame.getContentPane().add(btnNewButton);
		
		btnAurirajPodatke = new JButton("AŽURIRAJ PODATKE");
		btnAurirajPodatke.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				int idVjezbaca=0, idTreninga=0;
				
				try{
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					String vjezbac = "SELECT id_vjezbaca FROM Vjezbac WHERE Broj_mobitela ='"+mobitel+"'";
					PreparedStatement psVjezbaca = con.prepareStatement(vjezbac);
					ResultSet rsVjezbaca = psVjezbaca.executeQuery();
					
					if(rsVjezbaca.next()) {
						idVjezbaca=rsVjezbaca.getInt(1);
					}
					
					int oznaceniRedak = table.getSelectedRow();
					
					if(oznaceniRedak>=0) {
						
						String naziv = table.getValueAt(oznaceniRedak, 0).toString();
						String opterecenje = table.getValueAt(oznaceniRedak, 4).toString();
						String brojSerija = table.getValueAt(oznaceniRedak, 5).toString();
						
						if((parsiranjeDecimalnog(opterecenje)) && (parsiranjeIntegera(brojSerija))) {
							
							float opterecenjes=Float.parseFloat(opterecenje);
							int brojs= Integer.parseInt(brojSerija);
							
							String trening = "SELECT id_treninga FROM Trening WHERE naziv_vjezbe='"+naziv+"'";
							PreparedStatement psTreninga = con.prepareStatement(trening);
							ResultSet rsTreninga = psTreninga.executeQuery();
							
							if(rsTreninga.next()) {
								idTreninga=rsTreninga.getInt(1);
							}
							
							String azuriraj = "UPDATE Progres_vjezbaca SET podignuto_opterecenje=?, broj_ponavljanja_unutar_radne_serije=? WHERE id_vjezbaca='"+idVjezbaca+"' AND id_treninga='"+idTreninga+"'";
							PreparedStatement psAzuriraj = con.prepareStatement(azuriraj);
							
							psAzuriraj.setFloat(1, opterecenjes);
							psAzuriraj.setInt(2, brojs);
							
							int azurirano = psAzuriraj.executeUpdate();
							
							if(azurirano==1) {
								JOptionPane.showMessageDialog(null, "Ažuriranje uspješno.");
							}else {
								JOptionPane.showMessageDialog(null, "Ažuriranje neuspješno.");
								
							}
							
						}else {
							JOptionPane.showMessageDialog(null, "Niste unijeli ispravne vrijednosti. Opterecenje = decimalan broj. Ponavljanja = cijeli broj.");
						}
						
						
						
						
					}else {
						JOptionPane.showMessageDialog(null, e);
						
					}
					
					
				}catch(Exception e1) {
					System.out.println(e1);
				}
				
				
			}
		});
		btnAurirajPodatke.setBounds(790, 406, 268, 58);
		frame.getContentPane().add(btnAurirajPodatke);
		
		btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mobitel = lblNewLabel.getText();
				
				OdabirTreningaVjezbac povratak = new OdabirTreningaVjezbac();
				povratak.lblNewLabel.setText(mobitel);
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(10, 441, 59, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		btnAurirajteTjelesnuTeinu = new JButton("AŽURIRAJTE TJELESNU TEŽINU");
		btnAurirajteTjelesnuTeinu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				String mobitel = lblNewLabel.getText();
				String tezina = ttezina.getText();
				float ttezinas=0;
								
				try {
					
					ttezinas = Float.parseFloat(tezina);
					
					try {
						
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
						
						String tjelesnaTezina = "UPDATE Vjezbac SET Tjelesna_tezina=? WHERE Broj_mobitela='"+mobitel+"'";
						PreparedStatement psTezine = con.prepareStatement(tjelesnaTezina);
						
						psTezine.setFloat(1, ttezinas);
						
						int azurirano = psTezine.executeUpdate();
						
						if(azurirano==1) {
							JOptionPane.showMessageDialog(null, "Ažuriranje uspješno.");
						}else {
							JOptionPane.showMessageDialog(null, "Ažuriranje neuspješno.");
							
						}
					}catch(Exception e1) {
						JOptionPane.showMessageDialog(null, "Pogreška prilikom spajanja na bazu.");
					}
					
				}catch(Exception e4) {
					JOptionPane.showMessageDialog(null, "Tjelesna težina mora biti numerička vrijednost.");
				}
				
			}
		});
		btnAurirajteTjelesnuTeinu.setBounds(411, 406, 268, 58);
		frame.getContentPane().add(btnAurirajteTjelesnuTeinu);
		table.getColumnModel().getColumn(0).setPreferredWidth(206);
		table.getColumnModel().getColumn(1).setPreferredWidth(145);
		table.getColumnModel().getColumn(2).setPreferredWidth(161);
		table.getColumnModel().getColumn(3).setPreferredWidth(141);
		table.getColumnModel().getColumn(4).setPreferredWidth(161);
		table.getColumnModel().getColumn(5).setPreferredWidth(126);
	}
	public void showWindow() {
		frame.setVisible(true);
	}
	
	public void closeWindow() {
		frame.setVisible(false);
	}
	
	public static boolean parsiranjeIntegera(String podatak) {
		
		try {
			
			Integer.parseInt(podatak);
			return true;
			
		}catch(Exception e1) {
			return false;
		}

		
	}
	
	public static boolean parsiranjeDecimalnog(String podatak) {
		
		try {
			
			Float.parseFloat(podatak);
			return true;
			
		}catch(Exception e1) {
			return false;
		}
		
	}
}
