package fitnessAplikacija;
import fitnessAplikacija.Login;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class PopisTreninga {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PopisTreninga window = new PopisTreninga();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PopisTreninga() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("1. TRENING");
		btnNewButton.setBounds(126, 45, 132, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2. TRENING");
		btnNewButton_1.setBounds(126, 92, 132, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnTrening = new JButton("3. TRENING");
		btnTrening.setBounds(126, 138, 132, 23);
		frame.getContentPane().add(btnTrening);
		
		JButton btnNewButton_1_1 = new JButton("4. TRENING");
		btnNewButton_1_1.setBounds(126, 185, 132, 23);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("<-");
		btnNewButton_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login povratak = new Login();
				povratak.showWindow();
				
			}
		});
		btnNewButton_1_2.setBounds(10, 229, 58, 23);
		frame.getContentPane().add(btnNewButton_1_2);
	}
}
