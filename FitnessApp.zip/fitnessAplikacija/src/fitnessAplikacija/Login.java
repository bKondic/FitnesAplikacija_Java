package fitnessAplikacija;
import fitnessAplikacija.OdabirTreningaVjezbac;
import fitnessAplikacija.Idle;
import fitnessAplikacija.PrviTreningVjezbac;
import java.sql.*;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.mindrot.jbcrypt.BCrypt;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login {

	private JFrame frame;
	private JTextField brojMobitela;
	private JPasswordField lozinka;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static boolean provjeraPraznogPolja(String unos) {
		
		if(unos.length() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 428, 227);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UNESITE BROJ MOBITELA");
		lblNewLabel.setBounds(10, 45, 164, 14);
		frame.getContentPane().add(lblNewLabel);
		
		brojMobitela = new JTextField();
		brojMobitela.setBounds(200, 42, 148, 20);
		frame.getContentPane().add(brojMobitela);
		brojMobitela.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("UNESITE LOZINKU");
		lblNewLabel_1.setBounds(10, 70, 148, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(200, 67, 148, 20);
		frame.getContentPane().add(lozinka);
		
		JButton btnNewButton = new JButton("PRIJAVA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String brojMobitelas, lozinkas;
				brojMobitelas = brojMobitela.getText();
				lozinkas = new String(lozinka.getPassword());
				
				if(provjeraPraznogPolja(brojMobitelas)) {
					JOptionPane.showMessageDialog(null, "Niste unijeli broj mobitela.");
				}else {
					
					if(provjeraPraznogPolja(lozinkas)) {
						JOptionPane.showMessageDialog(null, "Niste unijeli lozinku.");
					}else {
											
						try {
							
							Class.forName("com.mysql.cj.jdbc.Driver");
							Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
							
							String dohvatHasha = "SELECT Lozinka FROM Vjezbac WHERE Broj_mobitela='"+brojMobitelas+"'";
							PreparedStatement psHasha = con.prepareStatement(dohvatHasha);
							ResultSet rsHasha = psHasha.executeQuery();
							
							
							if(rsHasha.next()) {
								
								String hashLozinka = rsHasha.getString(1);
								
								if(BCrypt.checkpw(lozinkas, hashLozinka)) {
									
									OdabirTreningaVjezbac treninzi = new OdabirTreningaVjezbac();
									treninzi.lblNewLabel.setText(brojMobitelas);
									treninzi.showWindow();
									closeWindow();
									
								}else {
									JOptionPane.showMessageDialog(null, "Pogrešna lozinka. Prijava je neuspješna");
								}
								
							}
							
						}catch(Exception e1) {
							JOptionPane.showMessageDialog(null, "Greška priliko spajanja na server.");
						}											
					}										
				}											
			}
		});
		btnNewButton.setBounds(120, 112, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Idle povratak = new Idle();
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(10, 156, 58, 23);
		frame.getContentPane().add(btnNewButton_1);
		
	}

	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		frame.setVisible(false);
	}
}
