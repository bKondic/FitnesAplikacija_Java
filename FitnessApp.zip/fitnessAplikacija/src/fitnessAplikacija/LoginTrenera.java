package fitnessAplikacija;
import fitnessAplikacija.KlijentiIliTreningzi;
import fitnessAplikacija.PocetniZaslon;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class LoginTrenera {

	private JFrame frame;
	private JTextField ime;
	private JPasswordField lozinka;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginTrenera window = new LoginTrenera();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static boolean provjeraPraznogPolja(String unos) {
			
			if(unos.length() == 0) {
				return true;
			}
			return false;
		}

	/**
	 * Create the application.
	 */
	public LoginTrenera() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 442, 265);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("IME");
		lblNewLabel.setBounds(10, 56, 63, 14);
		frame.getContentPane().add(lblNewLabel);
		
		ime = new JTextField();
		ime.setBounds(218, 53, 159, 20);
		frame.getContentPane().add(ime);
		ime.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("LOZINKA");
		lblNewLabel_1.setBounds(10, 105, 152, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		lozinka = new JPasswordField();
		lozinka.setBounds(218, 102, 159, 20);
		frame.getContentPane().add(lozinka);
		
		JButton btnNewButton = new JButton("PRIJAVA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String imes, lozinkas;
				imes = ime.getText();
				lozinkas = new String(lozinka.getPassword());
				
				if(provjeraPraznogPolja(imes)) {
					JOptionPane.showMessageDialog(null, "Niste unijeli ime.");
				}else {
					
					if(provjeraPraznogPolja(lozinkas)) {
						JOptionPane.showMessageDialog(null, "Niste unijeli lozinku.");
					}else {
						
						try {
							
							Class.forName("com.mysql.cj.jdbc.Driver");
							Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
							
							String select = "SELECT * FROM Trener WHERE Ime=? AND lozinka=?";
							PreparedStatement psSelect = con.prepareStatement(select);
							
							psSelect.setString(1, imes);
							psSelect.setString(2, lozinkas);
							
							ResultSet rs = psSelect.executeQuery();
							
							if(rs.next()) {

								KlijentiIliTreningzi mogucnosti = new KlijentiIliTreningzi();
								mogucnosti.showWindow();
								closeWindow();
								
							}else {
								JOptionPane.showMessageDialog(null, "Prijava je neuspješna.");
							}
							
							
						}catch(Exception e1) {
							JOptionPane.showMessageDialog(null, "Greška priliko spajanja na server.");
						}											
					}										
				}
				
			}
		});
		btnNewButton.setBounds(101, 156, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PocetniZaslon povratak = new PocetniZaslon();
				povratak.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(10, 194, 58, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		
	}

	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
}
