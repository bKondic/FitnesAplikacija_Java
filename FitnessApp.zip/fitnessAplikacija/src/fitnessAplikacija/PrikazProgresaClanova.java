package fitnessAplikacija;
import fitnessAplikacija.KlijentiIliTreningzi;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class PrikazProgresaClanova {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrikazProgresaClanova window = new PrikazProgresaClanova();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrikazProgresaClanova() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
			}
		});
		frame.setBounds(100, 100, 1152, 646);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ODABERI IME ČLANA");
		lblNewLabel.setBounds(10, 26, 176, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblOdaberiPrezimelana = new JLabel("ODABERI PREZIME ČLANA");
		lblOdaberiPrezimelana.setBounds(10, 56, 176, 14);
		frame.getContentPane().add(lblOdaberiPrezimelana);
		
		JComboBox comboIme = new JComboBox();
		comboIme.setBounds(272, 22, 223, 22);
		frame.getContentPane().add(comboIme);
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
			
			String ispisImena = "SELECT Ime FROM Vjezbac";
			Statement stImena = con.createStatement();
			ResultSet rsImena = stImena.executeQuery(ispisImena);
			
			while(rsImena.next()) {
				String podatak = rsImena.getString(1);
				comboIme.addItem(podatak);
			}
			
		}catch(Exception e1) {
			JOptionPane.showMessageDialog(null, e1);
		}
		
		JComboBox comboPrezime = new JComboBox();
		comboPrezime.setBounds(272, 52, 223, 22);
		frame.getContentPane().add(comboPrezime);
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
			
			String ispisPrezimena = "SELECT Prezime FROM Vjezbac";
			Statement stPrezimena = con.createStatement();
			ResultSet rsPrezimena = stPrezimena.executeQuery(ispisPrezimena);
			
			while(rsPrezimena.next()) {
				String podatak = rsPrezimena.getString(1);
				comboPrezime.addItem(podatak);
			}
			
		}catch(Exception e1) {
			JOptionPane.showMessageDialog(null, e1);
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 81, 1118, 479);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"IME", "PREZIME", "NAZIV VJE\u017DBE", "PODIGNUTO OPTERE\u0106ENJE"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setPreferredWidth(131);
		table.getColumnModel().getColumn(1).setPreferredWidth(139);
		table.getColumnModel().getColumn(2).setPreferredWidth(256);
		table.getColumnModel().getColumn(3).setPreferredWidth(162);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("PRIKAŽI PROGRES");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String odabirImena = (String) comboIme.getSelectedItem();
				String odabirPrezimena = (String) comboPrezime.getSelectedItem();
				
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/bkondic?serverTimezone=UTC","bkondic","11");
					
					String prikazProgresaClanova = "SELECT Vjezbac.Ime, Vjezbac.Prezime, Trening.naziv_vjezbe, Progres_vjezbaca.podignuto_opterecenje\r\n"
							+ "FROM Vjezbac\r\n"
							+ "LEFT OUTER JOIN Progres_vjezbaca \r\n"
							+ "ON Vjezbac.id_vjezbaca=Progres_vjezbaca.id_vjezbaca\r\n"
							+ "LEFT OUTER JOIN Trening \r\n"
							+ "ON Progres_vjezbaca.id_treninga=Trening.id_treninga WHERE Vjezbac.Ime='"+odabirImena+"' AND Vjezbac.Prezime='"+odabirPrezimena+"'";
					
					Statement stProgresaClanova = con.createStatement();
					ResultSet rsProgresaClanova = stProgresaClanova.executeQuery(prikazProgresaClanova);
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.setRowCount(0);
					
					while(rsProgresaClanova.next()) {
						
						String ime = rsProgresaClanova.getString(1);
						String prezime = rsProgresaClanova.getString(2);
						String naziv_vjezbe = rsProgresaClanova.getString(3);
						double opterecenje = rsProgresaClanova.getDouble(4);
						
						model.addRow(new Object[] {ime, prezime, naziv_vjezbe, opterecenje});
						
					}
					
					
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				
			}
		});
		btnNewButton.setBounds(834, 575, 282, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("<-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				KlijentiIliTreningzi mogucnosti = new KlijentiIliTreningzi();
				mogucnosti.showWindow();
				closeWindow();
				
			}
		});
		btnNewButton_1.setBounds(20, 575, 50, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		
	}
	
	public void showWindow() {
		
		frame.setVisible(true);
		
	}
	
	public void closeWindow() {
		
		frame.setVisible(false);
		
	}
}
